#ifndef STRING_FN_H_INCLUDED
#define STRING_FN_H_INCLUDED

bool check_palindrome(const char*);
char* rev_str(const char*);
int find_substr(const char*, const char*);
int count_word(const char*);

#endif // STRING_FN_H_INCLUDED
