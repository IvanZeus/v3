#include"String_fn.h"
#include<iostream.h>

bool check_palindrome(const char* str)
{
    int s = e = 0;=
    while(str[e]!='\0')
        e++;
    e = e-1;
    while(str[s]==str[e]&&s<=e)
    {
        s++;
        e--;
    }
    if(s>e)
        return true;
    else
        return false;
}

char* rev_str(const char* str)
{
    char* rev;
    int s = e = 0;
    while(str[e]!='\0')
        e++;
    rev = new char[e];
    e = e-1;
    int i;
    for(i=0;i<=e/2;i++)
        rev[i] = str[e-i];
    return rev;
}

int find_substr(const char* str, const char* sub_str )
{
        int i=0;
        int j,t;
        while(str[i]!='\0')
        {
            j = 0;
            if(str[i]==sub_str[j])
            {
                t = i;
                while(str[i]==sub_str[j]&&str[i]!='\0')
                {
                    i++;
                    j++;
                }
                if(str[i]==sub_str[j])
                    return t;
            }
            else
                i++;
        }
        return -1;
}
int count_word(char* str)
{
    int space = 0;
    int word;
    int i = 0;
    while(str[i]!='\0')
    {
        if(str[i]==' ')
            space++;
        i++;
    }
    word = space+1;
    return word;
}
