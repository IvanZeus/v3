#ifndef SORT_H_INCLUDED
#define SORT_H_INCLUDED

void quick_sort(int*,int,int);

void insertion_sort(int* ,int);

void merge_sort(int*,  int);

void selection_sort(int*, int);

void bubble_sort(int*, int);

#endif // SORT_H_INCLUDED
