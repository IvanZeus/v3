#include"sort.h"
#include<iostream>

void Merge(int* arr, int s, int m, int e)
{
    int x,y;
    x = m-s+1;
    y = e-m;
    int* A;
    int* B;
    A = new int[x];
    B = new int[y];
    int i,j;
    for(i=0;i<x;i++)
        A[i]=arr[s+i];
    for(j=0;j<y;j++)
        B[j] = arr[m+1+j];

    i = j = 0;
    int k=s;
    while(i<x&&j<y)
    {
        if(A[i]<B[j])
        {
            arr[k++]=A[i];
            i++;
        }
        else
        {
            arr[k++]=B[j];
            j++;
        }
    }
    if(i<x)
    {
        while(i<x)
            arr[k++]=A[i++];
    }
    else
    {
        while(j<y)
            arr[k++]=B[j++];
    }
}

void merge_sort(int* arr, int start, int End)
{
    if(start<End){
        int mid = (start+End)/2;

        merge_sort(arr,start,mid);
        merge_sort(arr,mid+1,End);

        Merge(arr,start,mid,End);
    }
}
