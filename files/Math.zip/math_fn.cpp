#include"math_fn.h"
#include<iostream>
#include<math.h>
using namespace std;

int factorial(int n)
{
    int fact = 1;
    while(n>0)
    {
        fact *= n;
        n--;
    }
    return fact;
}

int nPr(int n, int r)
{
    int num;
    int x = factorial(n);
    int y = factorial(n-r);
    num = x/y;
    return num;
}

int nCr(int n, int r)
{
    int num;
    int x = nPr(n,r);
    int y = factorial(r);
    num = x/y;
    return num;
}

int rev_num(int n)
{
        int rev = 0;
        int rem;
        while(n>0)
        {
            rem = n%10;
            rev = 10*rev + rem;
            n = n/10;
        }
}

int digit_sum(int n)
{
    int sum = 0;
    int rem;
    while(n>0)
    {
        rem = n%10;
        sum += rem;
        n = n/10;
    }
}

int gcd(int a, int b)
{
    if(a<b)
    {
        int t;
        t = a;
        a = b;
        b = t;
    }
    int rem;
    rem = a%b;
    while(rem!=0)
    {
        a = b;
        b = rem;
        rem = a%b;
    }
    return b;
}
int lcm(int a,int b)
{
    if(a<b)
    {
        int t;
        t=a;
        a=b;
        b=t;
    }
    int l = a;
    while(l%a!=0||l&b!=0)
    {
        l+=a;
    }
    return l;
}
bool isprime(int n)
{
    int i;
    int root  = pow(n,0.5);
    for(i=2;i<=root;i++)
    {
        if(n%i==0)
            break;
    }
    if(i>root)
        return true;
    else
        return false;
}
void remove_multiple(int* arr, int n, int e)
{
    int i;
    for(i=2*n;i<=e;i+=n)
        arr[i]=0;
}
void find_prime(int s,int e)
{
    int i;
    int* arr;
    arr = new int[e];
    for(i=1;i<=e;i++)
        arr[i]=1;
    for(i=2;i<=e;i++)
    {
        if(arr[i]==1)
            remove_multiple(arr, arr[i],e);
    }
    for(i=s;i<=e;i++)
        if(arr[i]==1)
            cout<<arr[i]<<"\t";
}
