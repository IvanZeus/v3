#ifndef MATH_FN_H_INCLUDED
#define MATH_FN_H_INCLUDED

int factorial(int);
int nCr(int, int);
int nPr(int, int);
int gcd(int,int);
int lcm(int, int);
int rev_num(int);
int digit_sum(int);

bool isprime(int n);
void find_prime(int,int);


#endif // MATH_FN_H_INCLUDED
